﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
  class NumberClass
  {
    private double numberValue;
    private string stringValue;

    public string StringValue
    {
      get { return stringValue; }
      set
      {
        stringValue = value;
        numberValue = Convert.ToDouble(stringValue);
      }
    }

    public double NumberValue
    {
      get { return numberValue; }
      set
      {
        numberValue = value;
        stringValue = numberValue.ToString();
      }
    }

    public NumberClass()
    {

    }
  }
}
